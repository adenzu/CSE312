You can find respective ReadMe's in each part's respective file.
